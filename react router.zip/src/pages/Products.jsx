import { useState, useEffect } from "react";
import { Link } from 'react-router';

function Products() {
    const [products, setProducts] = useState([]);
    const [type, setType] = useState('burger');

    useEffect(() => {
        fetchProducts();
    }, [type]);

    const fetchProducts = async () => {
        const response = await fetch(`https://titi.startwin.fr/products/type/${type}`);
        const data = await response.json();
        setProducts(data);
    }

    return (
        <>
            <h1>Carte du resto</h1>
            <button onClick={() => setType('burger')}>Burger</button>
            <button onClick={() => setType('accompagnement')}>Accompagnement</button>
            <button onClick={() => setType('dessert')}>Dessert</button>
            <button onClick={() => setType('boisson')}>Boisson</button>

            <select onChange={e => setType(e.target.value)}>
                <option value="burger">Burger</option>
                <option value="accompagnement">accompagnement</option>
                <option value="dessert">dessert</option>
                <option value="boisson">boisson</option>
            </select>

            <div className="grid">
                {products.map(product => (
                    <Link to={`/produit/${product._id}`} key={product._id}>
                        <h2>{product.name}</h2>
                        <img src={`https://titi.startwin.fr/${product.image}`} alt={product.name} />
                        <p>{product.price.$numberDecimal} €</p>
                    </Link>
                ))}
            </div>
        </>
    )
}

export default Products
