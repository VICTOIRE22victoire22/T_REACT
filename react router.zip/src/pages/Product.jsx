import { useParams } from "react-router";
import { useEffect, useState } from "react";
const Product = () => {
    // Ici on récupère l'id de l'url avec useParams
    // l'id doit correspondre au parametre mis en place de le router
    // Donc si dans le router j'ai /produit/:id, alors je recuperer const {id} = useParams();
    const { id } = useParams();

    const [product, setProduct] = useState({});

    useEffect(() => {
        fetchProduct();
    }, []);

    const fetchProduct = async () => {
        const response = await fetch(`https://titi.startwin.fr/products/${id}`);
        const data = await response.json();
        setProduct(data);
    }

    return (
        <>
            <h1>Page produit</h1>
            <h2>{product.name}</h2>
            <p>{product.description}</p>
            <img src={`https://titi.startwin.fr/${product.image}`} alt={product.name} />
        </>
    )
}

export default Product;