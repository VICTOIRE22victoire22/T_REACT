import { BrowserRouter, Routes, Route } from 'react-router';
import Products from './pages/Products';
import Product from './pages/Product';

function App() {

  return (
    <BrowserRouter>
      <Routes>
        {/* Le / correspond a la page d'accueil */}
        {/* Le path correpond a l'URL du navigateur qu'on veux definir */}
        {/* L'element c'est la page qui va etre affichée pour cette URL */}
        <Route path="/" element={<Products />} />
        <Route path="/produit/:id" element={<Product />} />
      </Routes>
    </BrowserRouter>
  )
}

export default App
