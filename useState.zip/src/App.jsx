import { useState } from 'react';

const App = () => {
  const [firstName, setFirstName] = useState("Théo");

  const changeName = () => {
    setFirstName("Audrey");
  }

  return (
    <>
      <h1>Coucou</h1>
      <h2 onClick={changeName}>{firstName}</h2>
      <ul>
        <li>1</li>
        <li>2</li>
        <li>3</li>
        <li>4</li>
      </ul>
    </>
  )
}

export default App