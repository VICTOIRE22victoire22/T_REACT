import { useEffect, useState } from 'react';
import './App.css';

function Search() {
    const [search, setSearch] = useState('');
    const [countries, setCountries] = useState([]);

    const fetchCountries = async () => {
        try {
            const response = await fetch(`https://restcountries.com/v3.1/name/${search}`);

            if (!response.ok) {
                throw new Error("Pays introuvable");
            }

            const data = await response.json();
            setCountries(data);
        } catch {
            setCountries([]);
        }
    }

    useEffect(() => {
        if (search.length < 2) return setCountries([]);
        fetchCountries();
    }, [search]);

    return (
        <>
            <input type="text" onChange={e => setSearch(e.target.value)} />
            <div className="grid">
                {countries.map(country => (
                    <div key={country.cca3}>
                        <h2>{country.translations.fra.common}</h2>
                        <img src={country.flags.svg} alt={country.flags.alt ?? country.name.common} />
                        <h3>Continent : {country.region}</h3>
                        <h3>Capital : </h3>
                        <ul>
                            {country?.capital?.map(capital => (
                                <li key={capital}>{capital}</li>
                            ))}
                        </ul>
                        {/* Ajouter un lien en savoir plus */}
                    </div>
                ))}
            </div>
        </>
    )
}

export default Search
