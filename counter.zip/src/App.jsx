import { useState } from 'react';
import "./App.css";

function App() {
  const [counter, setCounter] = useState(0);

  const minus = () => {
    setCounter(counter - 1);
  }

  const plus = () => {
    setCounter(counter + 1);
  }

  // Ternaire
  // condition ? si Oui : si non 

  // if (condition) {
  //   si oui 
  // } else {
  //   si non
  // }

  return (
    <>
      <h1>Counter</h1>
      <button onClick={minus}>-</button>
      <p className={counter < 0 ? 'red' : 'green'}>{counter}</p>
      <button onClick={plus}>+</button>
    </>
  )
}

export default App
