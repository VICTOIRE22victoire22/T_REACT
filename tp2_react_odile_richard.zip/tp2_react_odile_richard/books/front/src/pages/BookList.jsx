import { useParams, useNavigate } from "react-router";
import { useState, useEffect } from 'react';

const Book = () => {
    const navigate = useNavigate();
    const { id } = useParams();
    const [book, setBook] = useState({});
    const [authors, setAuthors] = useState([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        fetchAuthors()
        fetchBook();
    }, []);

    const fetchAuthors = async () => {
        const response = await fetch("http://localhost:3000/authors");
        const data = await response.json();
        setAuthors(data);
    }

    const fetchBook = async () => {
        try {
            const response = await fetch(`http://localhost:3000/books/${id}`);
            const data = await response.json();
            console.log(data);
            setBook(data);
        } catch {
            console.log("error");
        } finally {
            setLoading(false);
        }
    }

    const handleSubmit = async (e) => {
        e.preventDefault();

        const formData = new FormData(e.target);

        const book = {
            title: formData.get('title'),
            coverImage: formData.get("coverImage"),
            publishedYear: formData.get("publishedYear"),
            author: formData.get('author')
        }

        const response = await fetch(`http://localhost:3000/books/${id}`, {
            method: "PUT",
            headers: {

                'Content-Type': 'application/json'
            },
            body: JSON.stringify(book)
        })

        if (response.ok) {
            navigate('/');
        }
    }

    if (loading) {
        return <p>Chargement...</p>
    }

    return (
        <div>
            <form onSubmit={handleSubmit}>
                <label>
                    Titre <input type="text" name="title" defaultValue={book.title} />
                </label>

                <label>
                    Image de couverture <input type="text" name="coverImage" defaultValue={book.coverImage} />
                </label>

                <label>
                    Année de publication <input type="number" name="publishedYear" defaultValue={book.publishedYear} />
                </label>

                <select name="author" defaultValue={book.author?._id}>
                    {authors.map(author => (
                        <option key={author._id} value={author._id} >{author.name}</option>
                    ))}
                </select>
                <button>Modifier le livre</button>
            </form>
        </div>
    );
};

export default Book;