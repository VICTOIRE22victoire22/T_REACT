import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router';

const BookForm = () => {
    const navigate = useNavigate();
    const [authors, setAuthors] = useState([]);

    useEffect(() => {
        fetchAuthors()
    }, []);

    const fetchAuthors = async () => {
        const response = await fetch("http://localhost:3000/authors");
        const data = await response.json();
        setAuthors(data);
    }

    const handleSubmit = async (e) => {
        e.preventDefault();

        const formData = new FormData(e.target);

        const book = {
            title: formData.get('title'),
            coverImage: formData.get("coverImage"),
            publishedYear: formData.get("publishedYear"),
            author: formData.get('author')
        }

        const response = await fetch("http://localhost:3000/books", {
            method: "POST",
            headers: {

                'Content-Type': 'application/json'
            },
            body: JSON.stringify(book)
        })

        if (response.ok) {
            navigate('/');
        }
    }

    return (
        <div>
            <h1>Creation de livre</h1>
            <form onSubmit={handleSubmit}>
                <label>
                    Titre <input type="text" name="title" />
                </label>

                <label>
                    Image de couverture <input type="text" name="coverImage" />
                </label>

                <label>
                    Année de publication <input type="number" name="publishedYear" />
                </label>

                <select name="author">
                    {authors.map(author => (
                        <option key={author._id} value={author._id}>{author.name}</option>
                    ))}
                </select>
                <button>Creer le livre</button>
            </form>
        </div>
    );
};

export default BookForm;