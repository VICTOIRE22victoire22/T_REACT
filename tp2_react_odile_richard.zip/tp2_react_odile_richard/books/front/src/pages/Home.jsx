import { useEffect, useState } from "react";
import { Link } from "react-router";
import "../assets/Home.css";

const Home = () => {
    const [books, setBooks] = useState([]);

    useEffect(() => {
        fetchBooks();
    }, []);

    const fetchBooks = async () => {
        const response = await fetch("http://localhost:3000/books");
        const data = await response.json();
        setBooks(data);
    }

    const handleDelete = async (id) => {
        const response = await fetch(`http://localhost:3000/books/${id}`, {
            method: "DELETE"
        })

        if (response.ok) {
            await fetchBooks();
            alert("La suppression à bien été effectuée");
        }
    }

    return (
        <div className="home">
            {books.map(book => (
                <div key={book._id} className="book">
                    <h2>{book.title}</h2>
                    <img src={book.image} alt={book.title} />
                    <h3>{book.author.name}</h3>
                    <Link to={`/recette/${book._id}`}>Modifier</Link>
                    <br />
                    <button onClick={() => handleDelete(book._id)}>Supprimer</button>
                </div>
            ))}
        </div>
    );
};

export default Home;