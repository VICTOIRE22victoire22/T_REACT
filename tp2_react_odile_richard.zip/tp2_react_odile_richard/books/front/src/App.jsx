import { BrowserRouter, Routes, Route } from "react-router";
import Home from "./pages/Home";
import BookList from "./pages/BookList";
import BookForm from "./pages/BookForm";

function App() {

  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/book/:id" element={<BookList />} />
        <Route path="/book" element={<BookForm />} />
      </Routes>
    </BrowserRouter>
  )
}

export default App
