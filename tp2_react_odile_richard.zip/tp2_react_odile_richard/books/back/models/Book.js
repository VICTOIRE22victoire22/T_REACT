const mongoose = require('mongoose');

const bookSchema = mongoose.Schema({
    title: {
        required: true,
        type: String
    },
    coverImage: {
        required: true,
        type: String,
        validate: {
            validator: function (value) {
                const urlPattern = /^(https?:\/\/)?([\w-]+(\.[\w-]+)+)([?].*)?$/;
                return urlPattern.test(value);
            },
            message: "L'URL de l'image de couverture est invalide"
        }
    },
    publishedYear: {
        required: true,
        type: Number
    },
    author: {
        required: true,
        type: mongoose.Schema.Types.ObjectId,
        ref: "Author"
    }
})

const Book = mongoose.model("Book", bookSchema);

module.exports = Book;
