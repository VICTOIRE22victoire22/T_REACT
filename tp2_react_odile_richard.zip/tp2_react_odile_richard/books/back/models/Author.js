const mongoose = require('mongoose');

const authorSchema = mongoose.Schema({
    name: {
        required: true,
        type: String
    },
    birthdate: {
        required: true,
        type: String,
        validate: {
            validator: function (value) {
                return /^\d{4}-\d{2}-\d{2}$/.test(value);
            },
            message: 'La date doit être au format YYYY-MM-DD'
        }
    }
});

const Author = mongoose.model("Author", authorSchema);

module.exports = Author;