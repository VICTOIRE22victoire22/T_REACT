const express = require("express");
const mongoose = require('mongoose');
const cors = require('cors');
const bookRoutes = require('./routes/book.route');
const authorRoutes = require('./routes/author.route');

const app = express();

mongoose.connect("mongodb://localhost:27017/exercice-book").then(() => {
    console.log("Connexion à la base de données effectuée");
}).catch(error => console.log(error));

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.use(cors({
    origin: "http://localhost:5173"
}))

app.use('/books', bookRoutes);
app.use('/authors', authorRoutes);

app.listen(3000, () => {
    console.log("le serveur est bien lancé sur l'URL http://localhost:3000");
})