const express = require('express');

const router = express.Router();

const AuthorController = require('../controllers/author.controller');

router.post('/', AuthorController.create);

router.get('/', AuthorController.getAll);

module.exports = router;