const Author = require('../models/Author');

class AuthorController {

    async getAll(req, res) {

        const authors = await Author.find();

        res.json(authors);
    }

    async create(req, res) {

        const author = await Author.create(req.body);

        res.json(author);
    }
}

module.exports = new AuthorController;