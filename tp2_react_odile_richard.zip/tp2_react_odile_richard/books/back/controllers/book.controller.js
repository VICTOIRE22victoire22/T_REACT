const Book = require('../models/Book');

class BookController {

    async getAll(req, res) {

        const books = await Book.find().populate('author');

        res.json(books);
    }

    async getOne(req, res) {
        const book = await Book.findById(req.params.id).populate('author');
    
        res.json(book);
    }

    async create(req, res) {

        const book = await Book.create(req.body);

        res.json(book);
    }

    async update(req, res) {
        const { id } = req.params;

        const book = await Book.findByIdAndUpdate(id, req.body, { new: true });

        res.json(book);
    }

    async delete(req, res) {
        const { id } = req.params;

        const book = await Book.findByIdAndDelete(id);

        res.json(book);
    }
}

module.exports = new BookController;