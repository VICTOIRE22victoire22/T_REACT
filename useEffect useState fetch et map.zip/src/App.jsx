import { useState, useEffect } from 'react';
import "./App.css";

const App = () => {
  const [firstName, setFirstName] = useState("Théo");
  const [burgers, setBurgers] = useState([]);

  const changeName = () => {
    setFirstName("Audrey");
  }

  // useEffect s'execute dans tous les cas au chargement de la page
  // le premier argument de useEffect est une fonction, anonyme ou non (généralement anonyme)
  // pour le 2eme argument, si il n'y en a pas, le useEffect s'executera au chargement de la page et a chaque modification de state (pour tous les states)
  // Si il y a un tableau vide, le useEffect s'executera uniquement lors du chargement de la page
  // Si il y a un tableau avec un ou plusieurs state, alors il s'executera a chaque modification de ce / ces state(s)
  useEffect(() => {
    fetchBurgers();

    // Fonctionne aussi, avec la gestion des promesses avec le .then
    // mais c'est moche (c'est personnel)
    // fetch('https://titi.startwin.fr/products/type/burger')
    // .then(response => response.json())
    // .then(data => setBurgers(data))
    // .catch(error => console.log(error));
  }, [])

  // Ici nous avons une fonction async, ce qui nous permet d'utilise le mot clé await dans cette fonction
  const fetchBurgers = async () => {
    try {
      // fetch prend un parametre minimum qui est l'URL de l'API que l'on souhaite appeler
      // Le mot clé await permet de préciser que nous attendons le résultat de fetch plutot que la promesse
      const response = await fetch("https://titi.startwin.fr/products/type/burger")
      // On demande à notre retour d'API de recuperer uniquement le contenu de la requete au format JSON
      // Ce qui va nous permettre ensuite de recuperer un tableau d'objet déja formé
      const data = await response.json();
      setBurgers(data);
    } catch (error) {
      console.error(error)
    }
  }

  return (
    <>
      <h1>Coucou</h1>
      <h2 onClick={changeName}>{firstName}</h2>
      <ul>
        <li>1</li>
        <li>2</li>
        <li>3</li>
        <li>4</li>
      </ul>

      <div className="grid">
        {burgers.map((burger, index) => (
          <div key={index}>
            <p>{burger.name}</p>
            <p>{burger.description}</p>
            <img src={`https://titi.startwin.fr/${burger.image}`} alt={burger.name} />
          </div>
        ))}
      </div>
    </>
  )
}

export default App