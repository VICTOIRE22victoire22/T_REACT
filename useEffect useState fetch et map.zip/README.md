# 🧠 Exercice React : Créer un compteur

## 🎯 Objectif

Créer un **compteur interactif** en React permettant d’incrémenter ou de décrémenter une valeur affichée à l’écran.

---

## 🛠️ Consignes

1. **Fonctionnalité principale** :
   - Afficher un nombre (le compteur) qui commence à 0.
   - Ajouter **deux boutons** : un pour augmenter le compteur, un pour le diminuer.
   - Lorsque l'utilisateur clique sur un bouton, la valeur affichée doit se mettre à jour automatiquement.

2. **Utilisation de `useState`** :
   - Utilisez le hook `useState` pour gérer l'état du compteur dans le composant.

3. **Composant** :
   - Le tout doit être contenu dans un seul composant React fonctionnel (par exemple `App`).

4. **CSS (facultatif)** :
   - Vous pouvez styliser votre compteur (alignement, couleurs, taille des boutons...) en modifiant le fichier `App.css`.
   - Pour cela, ajoutez vos règles CSS dans `App.css`, puis importez ce fichier dans votre composant à l’aide de :
     ```js
     import './App.css';
     ```

---

## ✅ Livrable attendu

- Un affichage fonctionnel du compteur.
- Des boutons interactifs qui modifient la valeur.
- Une utilisation correcte de `useState`.
- Bonus : une mise en forme avec CSS.

---

Bonne chance ! 💪
